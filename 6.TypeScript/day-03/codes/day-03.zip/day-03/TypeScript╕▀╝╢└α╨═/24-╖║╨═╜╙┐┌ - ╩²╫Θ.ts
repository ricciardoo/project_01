const strs = ['a', 'b', 'c']
strs.forEach(item => {})

const nums = [1, 3, 5]
nums.forEach(item => {})
