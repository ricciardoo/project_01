type Props = { a: number; b: string; c: boolean }
type PartialProps = Partial<Props>
