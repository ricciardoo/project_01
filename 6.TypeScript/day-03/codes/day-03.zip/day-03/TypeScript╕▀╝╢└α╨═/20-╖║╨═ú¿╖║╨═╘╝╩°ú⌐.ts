function id<Type>(value: Type[]): Type[] {
  value.length
  return value
}
