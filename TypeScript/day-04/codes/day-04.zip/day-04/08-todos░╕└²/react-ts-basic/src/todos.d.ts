// 类型声明文件：

// 任务项的类型
export type TodoItem = {
  id: number
  text: string
  done: boolean
}
