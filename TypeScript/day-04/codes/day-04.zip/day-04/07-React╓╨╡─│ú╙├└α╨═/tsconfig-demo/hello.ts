type Person = {
  name: string
  age: number
}

let p: Person = {
  name: 'jack',
  age: 18
}
