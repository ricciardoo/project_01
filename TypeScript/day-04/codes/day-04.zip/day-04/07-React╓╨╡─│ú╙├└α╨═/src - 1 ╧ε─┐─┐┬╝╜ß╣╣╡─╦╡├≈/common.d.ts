type A = {
  name: string
}
