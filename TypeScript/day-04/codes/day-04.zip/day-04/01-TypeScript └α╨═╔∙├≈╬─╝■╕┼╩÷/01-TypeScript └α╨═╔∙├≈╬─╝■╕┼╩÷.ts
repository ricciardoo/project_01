import axios from 'axios'

axios({
  url: '',
  method: 'GET'
})
