let arr = [1, 3, 5]
arr.forEach

document.querySelector

window
