// a.ts
import { Props } from './index'

// type Props = { x: number; y: number }

let p1: Props = {
  x: 1,
  y: 2
}
