type Props = { x: number; y: number }

export { Props }
