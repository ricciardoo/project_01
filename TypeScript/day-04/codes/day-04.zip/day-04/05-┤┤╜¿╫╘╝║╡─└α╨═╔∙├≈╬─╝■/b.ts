// b.ts
import { Props } from './index'

// type Props = { x: number; y: number }

let p2: Props = {
  x: 10,
  y: 22
}
