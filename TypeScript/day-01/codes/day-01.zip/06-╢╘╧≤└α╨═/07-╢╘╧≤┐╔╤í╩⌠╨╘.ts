function myAxios(config: { url: string; method?: string }) {}

myAxios({
  url: ''
})
