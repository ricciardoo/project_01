// let position: number[] = [39, 114, 1, ,3, 4]

// 使用 元组 ：
let position: [number, string] = [39, '114']
