function mySlice(start: number, end?: number): void {
  console.log('起始索引：', start, '结束索引：', end)
}

mySlice(10)
mySlice(1)
mySlice(1, 3)
