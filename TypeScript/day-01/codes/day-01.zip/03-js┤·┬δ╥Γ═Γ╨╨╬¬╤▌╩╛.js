let count = 18

count = '20'

count.toFixed()
