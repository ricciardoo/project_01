let age: number = 18

age = 20
// age = '30'
