let age: number = 18

// 这句代码报错
age = '20'

age.toFixed()
