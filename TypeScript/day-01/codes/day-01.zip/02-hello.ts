console.log('Hello ts 0202')
let age: number = 20
console.log(age)
