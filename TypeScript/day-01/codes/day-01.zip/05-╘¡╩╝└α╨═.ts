let age: number = 18

let myName: string = '刘老师'

let isLoading: boolean = false

let a: null = null

let b: undefined = undefined

let s: symbol = Symbol()
