console.log('Hello ts')
let age: number = 18
console.log(age)
