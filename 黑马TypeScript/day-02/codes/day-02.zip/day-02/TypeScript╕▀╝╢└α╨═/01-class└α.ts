class Person {
  age: number
  gender = '男'
  // gender: string = '男'
}

const p = new Person()

p.age
p.gender
