let songs: string[] = ['南山南', '成都']

enum Direction {
  Up = 'UP',
  Down = 'DOWN',
  Left = 'LEFT',
  Right = 'RIGHT'
}

function changeDirection(direction: Direction) {}

changeDirection(Direction.Up)

console.log(Direction)
