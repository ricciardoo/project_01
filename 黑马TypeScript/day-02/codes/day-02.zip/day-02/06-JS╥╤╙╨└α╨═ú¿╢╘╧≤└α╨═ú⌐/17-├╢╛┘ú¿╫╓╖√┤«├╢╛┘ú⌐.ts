// 字符串枚举：

enum Direction {
  Up = 'UP',
  Down = 'DOWN',
  Left = 'LEFT',
  Right = 'RIGHT'
}

function changeDirection(direction: Direction) {}

changeDirection(Direction.Up)
