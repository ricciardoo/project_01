let obj: any = { x: 0 }

// 访问不存在的属性 或者 赋值
// obj.aaa
// obj.aaa = 10

// 当作函数调用
// obj()

// 赋值给其他类型的变量
// let n: number = obj

// --

// let a
// a = 1
// a = ''
// a()

// function add(num1, num2) {}
// add(1, 2)
// add(1, '2')
// add(1, false)
