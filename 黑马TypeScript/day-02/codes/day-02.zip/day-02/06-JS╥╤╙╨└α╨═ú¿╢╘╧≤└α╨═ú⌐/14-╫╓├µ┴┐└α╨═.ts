let str1 = 'Hello TS'

const str2: 'Hello TS' = 'Hello TS'

let age: 18 = 18

function changeDirection(direction: 'up' | 'down' | 'left' | 'right') {}

changeDirection('left')
